/**
 * 
 */
/**
 * @author MaximuzPlayz
 *
 */
module MC02 {
	requires java.desktop;
}